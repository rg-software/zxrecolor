//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused
TColor MakeColor(TColor c1, TColor c2)
{
    if(c1 == clBlack && c2 == clBlack)
        return clBlack;
    else
        return clWhite;
}

int main(int argc, char* argv[])
{                                 
    TImage *p = new TImage(Application);
    TImage *center = new TImage(Application);
    TImage *corner = new TImage(Application);
    TImage *result = new TImage(Application);

    p->AutoSize = true;
    p->Picture->LoadFromFile(argv[1]);
    TRect r = Rect(0, 0, p->Width + 1, p->Height + 1);
    center->Width = p->Width; center->Height = p->Height;
    corner->Width = p->Width; corner->Height = p->Height;
    result->Width = p->Width; result->Height = p->Height;
    center->Canvas->Brush->Color = clWhite;
    center->Canvas->FillRect(r);
    corner->Canvas->Brush->Color = clWhite;
    corner->Canvas->FillRect(r);
    result->Canvas->Brush->Color = clWhite;
    result->Canvas->FillRect(r);

    center->Canvas->CopyRect(r, p->Canvas, r);
    corner->Canvas->CopyRect(r, p->Canvas, r);

    for(int i = 1; i < center->Width - 1; i++)
        for(int j = 1; j < center->Height - 1; j++)
            center->Canvas->Pixels[i][j] = MakeColor(p->Canvas->Pixels[i][j], p->Canvas->Pixels[i - 1][j + 1]);
    center->Picture->SaveToFile("aaa.bmp");

    for(int i = 1; i < corner->Width - 1; i++)
        for(int j = 1; j < corner->Height - 1; j++)
            corner->Canvas->Pixels[i][j] = MakeColor(p->Canvas->Pixels[i][j], p->Canvas->Pixels[i - 1][j - 1]);
    corner->Picture->SaveToFile("bbb.bmp");


    for(int i = 0; i < p->Width; i++)
        for(int j = 0; j < p->Height; j++)
            if(center->Canvas->Pixels[i][j] == clBlack || corner->Canvas->Pixels[i][j + 1] == clBlack)
                result->Canvas->Pixels[i][j] = clBlack;
            else
                result->Canvas->Pixels[i][j] = clWhite;

    result->Picture->SaveToFile(AnsiString("_") + argv[1]);
//    corner->Picture->SaveToFile(AnsiString("-") + argv[1]);
  //  center->Picture->SaveToFile(AnsiString("+") + argv[1]);
    return 0;
}
//---------------------------------------------------------------------------
 