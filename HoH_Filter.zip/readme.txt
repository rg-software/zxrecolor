ZX Filter implements graphic filter, proposed by the authors of Head Over Heels Remake
It takes double-sized Speccy screen, and "cleans" it, making it ready for future coloring.

Notes:
Input image should be double-sized Speccy screen, black and white (important!)
Any non-black pixel is considered to be white.

Call format:
ZXFilter <input-file>

Results: _<input-file>
also aaa.bmp and bbb.bmp (debug files)